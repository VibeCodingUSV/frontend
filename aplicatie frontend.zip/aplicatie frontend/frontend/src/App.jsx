import React, { useState, useEffect } from 'react';
import './index.css';


const API_BASE_URL = 'http://localhost:8080/api';

export default function App() {

  const [currentView, setCurrentView] = useState('admin-resources');
  const [apiStatus, setApiStatus] = useState({ text: 'Verificare status backend...', type: 'warning' });
  
  // Da teBackend
  const [resources, setResources] = useState([]);
  const [reservations, setReservations] = useState([]);
  
  //CRUD
  const [formData, setFormData] = useState({ id: '', name: '', location: '' });

  // Date Fake pentru User
  const fakeUserData = [
    { id: 101, name: "Imprimantă 3D ProMaker", location: "Laborator B2", status: "AVAILABLE" },
    { id: 102, name: "Kit Robotică Avansat", location: "Sala 104", status: "MAINTENANCE" },
    { id: 103, name: "Osciloscop Digital Fluke", location: "Laborator A1", status: "AVAILABLE" },
    { id: 104, name: "Sală Prezentări VR", location: "Corp C - Parter", status: "AVAILABLE" }
  ];

  
  useEffect(() => {
    fetchAdminData();
  }, []);

  
  const fetchAdminData = async () => {
    setApiStatus({ text: 'Se conectează la Spring Boot...', type: 'warning' });
    try {
      // Fetch Resurse
      const resResponse = await fetch(`${API_BASE_URL}/resources`);
      if (resResponse.ok) setResources(await resResponse.json());

      // Fetch Rezervări
      const revResponse = await fetch(`${API_BASE_URL}/reservations`);
      if (revResponse.ok) setReservations(await revResponse.json());

      setApiStatus({ text: 'Conectat (API Online)', type: 'success' });
    } catch (error) {
      console.error("Backend indisponibil:", error);
      setApiStatus({ text: 'Eroare Conexiune API', type: 'error' });
      setResources([]);
      setReservations([]);
    }
  };

  // CREATE UPDATE
  const handleResourceSubmit = async (e) => {
    e.preventDefault();
    const isUpdate = formData.id !== '';
    const method = isUpdate ? 'PUT' : 'POST';
    const endpoint = isUpdate ? `${API_BASE_URL}/resources/${formData.id}` : `${API_BASE_URL}/resources`;

    try {
      const response = await fetch(endpoint, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: formData.name, location: formData.location })
      });

      if (response.ok) {
        setFormData({ id: '', name: '', location: '' }); // Reset form
        fetchAdminData(); // Refresh UI
      } else {
        alert('A apărut o eroare la salvare în Backend.');
      }
    } catch (err) {
      alert('Eroare conexiune: Backend-ul nu e pornit?');
    }
  };

  // DELETE
  const deleteResource = async (id) => {
    if (!window.confirm(`Confirmi ștergerea resursei cu ID: ${id}?`)) return;
    try {
      const response = await fetch(`${API_BASE_URL}/resources/${id}`, { method: 'DELETE' });
      if (response.ok) fetchAdminData();
    } catch (err) { alert('Eroare la ștergere.'); }
  };

  const deleteReservation = async (id) => {
    if (!window.confirm(`Confirmi ștergerea rezervării cu ID: ${id}?`)) return;
    try {
      const response = await fetch(`${API_BASE_URL}/reservations/${id}`, { method: 'DELETE' });
      if (response.ok) fetchAdminData();
    } catch (err) { alert('Eroare la ștergere.'); }
  };

  // STILURI 
  const statusColors = {
    warning: 'bg-amber-100 text-amber-700 border-amber-200',
    success: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    error: 'bg-rose-100 text-rose-700 border-rose-200'
  };

  const getPageTitle = () => {
    if (currentView === 'admin-resources') return 'Panou Administrare Resurse';
    if (currentView === 'admin-reservations') return 'Panou Management Rezervări';
    return 'Catalog Resurse (Vizualizare Utilizator)';
  };

  return (
    <div className="flex w-full h-full">
      {/* SIDEBAR */}
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col flex-shrink-0 border-r border-slate-800 h-full">
        <div className="p-5 border-b border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-bold"><i className="fa-solid fa-code"></i></div>
          <div>
            <h1 className="font-bold text-white text-base leading-tight">Platforma RRM</h1>
            <p className="text-[10px] text-indigo-400 uppercase tracking-widest mt-0.5">React Frontend</p>
          </div>
        </div>
        <nav className="p-3 space-y-1">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 mt-4 px-3">Modul Admin (CRUD Real)</div>
          <button onClick={() => setCurrentView('admin-resources')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${currentView === 'admin-resources' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'}`}>
            <i className="fa-solid fa-server w-5 text-center"></i> Gestiune Resurse
          </button>
          <button onClick={() => setCurrentView('admin-reservations')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${currentView === 'admin-reservations' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'}`}>
            <i className="fa-solid fa-calendar-check w-5 text-center"></i> Tabel Rezervări
          </button>
          
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 mt-6 px-3">Modul User (Fake Data)</div>
          <button onClick={() => setCurrentView('user-catalog')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${currentView === 'user-catalog' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'}`}>
            <i className="fa-solid fa-cubes w-5 text-center"></i> Catalog Utilizator
          </button>
        </nav>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 flex flex-col h-full bg-slate-50 overflow-hidden">
        {/* HEADER */}
        <header className="h-14 bg-white border-b border-slate-200 px-6 flex items-center justify-between flex-shrink-0">
          <h2 className="text-lg font-bold text-slate-800">{getPageTitle()}</h2>
          <div className="flex items-center gap-3">
            <span className={`text-xs px-2.5 py-1 rounded font-bold border ${statusColors[apiStatus.type]}`}>{apiStatus.text}</span>
            <button onClick={fetchAdminData} className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold px-2 py-1"><i className="fa-solid fa-rotate mr-1"></i>Reîncarcă Datele</button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 view-section">
          
          {/* VIEW: ADMIN RESURSE */}
          {currentView === 'admin-resources' && (
            <div className="space-y-6">
              {/* Formular */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm max-w-3xl">
                <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                  <h3 className="font-bold text-slate-800"><i className="fa-solid fa-plus-circle text-indigo-600 mr-2"></i>{formData.id ? 'Editează Resursa' : 'Adaugă Resursă Nouă'}</h3>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-100 px-2 py-1 rounded">Metode: POST / PUT</span>
                </div>
                
                <form onSubmit={handleResourceSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Denumire Echipament / Sală</label>
                      <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} required className="w-full bg-slate-50 border border-slate-300 text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Locație (Corp / Etaj)</label>
                      <input type="text" value={formData.location} onChange={(e) => setFormData({...formData, location: e.target.value})} required className="w-full bg-slate-50 border border-slate-300 text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                    </div>
                  </div>
                  <div className="pt-2 flex justify-end gap-3">
                    <button type="button" onClick={() => setFormData({id: '', name: '', location: ''})} className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 transition">Curăță Formular</button>
                    <button type="submit" className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 shadow-md transition">Salvează în Baza de Date</button>
                  </div>
                </form>
              </div>

              {/* Tabel Resurse */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden max-w-5xl">
                <div className="bg-slate-50 p-4 border-b border-slate-200 flex items-center justify-between">
                  <h3 className="font-bold text-slate-800 text-sm"><i className="fa-solid fa-database text-slate-400 mr-2"></i>Baza de Date: Resurse</h3>
                  <span className="text-xs text-slate-500 font-mono">Metodă: GET</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead className="bg-white text-slate-500 uppercase text-xs font-semibold border-b border-slate-200">
                      <tr>
                        <th className="p-4 w-16">ID</th>
                        <th className="p-4">Nume Resursă</th>
                        <th className="p-4">Locație</th>
                        <th className="p-4 text-right">Acțiuni CRUD</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {resources.length === 0 ? (
                        <tr><td colSpan="4" className="p-4 text-center text-slate-500">Nu există resurse / Backend Offline.</td></tr>
                      ) : (
                        resources.map(res => (
                          <tr key={res.id} className="hover:bg-slate-50 transition">
                            <td className="p-4 font-mono text-slate-500 text-xs">{res.id}</td>
                            <td className="p-4 font-semibold text-slate-800">{res.name || res.title}</td>
                            <td className="p-4 text-slate-600">{res.location || res.room}</td>
                            <td className="p-4 text-right">
                              <button onClick={() => setFormData({id: res.id, name: res.name || res.title || '', location: res.location || res.room || ''})} className="px-3 py-1.5 bg-slate-100 text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 rounded text-xs font-bold transition mr-2"><i className="fa-solid fa-pen mr-1"></i> Update</button>
                              <button onClick={() => deleteResource(res.id)} className="px-3 py-1.5 bg-slate-100 text-slate-700 hover:bg-rose-50 hover:text-rose-600 rounded text-xs font-bold transition"><i className="fa-solid fa-trash mr-1"></i> Delete</button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: ADMIN REZERVĂRI */}
          {currentView === 'admin-reservations' && (
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden max-w-5xl">
              <div className="bg-slate-50 p-4 border-b border-slate-200 flex items-center justify-between">
                <h3 className="font-bold text-slate-800 text-sm"><i className="fa-solid fa-list-check text-slate-400 mr-2"></i>Toate Rezervările din Sistem</h3>
              </div>
              <table className="w-full text-left text-sm border-collapse">
                <thead className="bg-white text-slate-500 uppercase text-xs font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-4">ID</th>
                    <th className="p-4">Resursă</th>
                    <th className="p-4">User</th>
                    <th className="p-4 text-right">Acțiuni</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {reservations.length === 0 ? (
                    <tr><td colSpan="4" className="p-4 text-center text-slate-500">Nu există rezervări înregistrate.</td></tr>
                  ) : (
                    reservations.map(rev => (
                      <tr key={rev.id} className="hover:bg-slate-50 transition text-xs">
                        <td className="p-4 font-mono text-slate-500">{rev.id}</td>
                        <td className="p-4 font-semibold text-slate-800">{rev.resource?.name || `Resursa #${rev.resourceId}`}</td>
                        <td className="p-4 text-slate-600">{rev.user?.name || `User #${rev.userId || 'N/A'}`}</td>
                        <td className="p-4 text-right">
                          <button onClick={() => deleteReservation(rev.id)} className="px-3 py-1.5 bg-rose-50 text-rose-600 rounded font-bold hover:bg-rose-100 transition">Șterge (Delete)</button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* VIEW: USER CATALOG (FAKE DATA) */}
          {currentView === 'user-catalog' && (
            <div className="space-y-6">
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-amber-800 text-sm">Interfață Utilizator - Modul Mock/Fake</h3>
                  <p className="text-xs text-amber-700 mt-1">Date statice de test. Nu este conectat la backend.</p>
                </div>
                <i className="fa-solid fa-triangle-exclamation text-amber-500 text-2xl"></i>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {fakeUserData.map(item => {
                  const isAvail = item.status === 'AVAILABLE';
                  return (
                    <div key={item.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between h-full">
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-slate-800 text-base leading-tight pr-2">{item.name}</h4>
                          {isAvail ? (
                            <span className="bg-emerald-100 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Disponibil</span>
                          ) : (
                            <span className="bg-rose-100 text-rose-700 border border-rose-200 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Indisponibil</span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 font-medium mb-5"><i className="fa-solid fa-location-dot mr-1"></i> {item.location}</p>
                      </div>
                      <button disabled={!isAvail} className={`w-full py-2.5 rounded-lg text-xs font-bold transition shadow-sm ${isAvail ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}`}>
                        <i className="fa-regular fa-calendar-plus mr-1"></i> Formular Rezervare
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
